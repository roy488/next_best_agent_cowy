import React, { useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import { auth, onAuthStateChanged } from './firebase';
import Login from './components/Login';
import TelemarketerView from './components/TelemarketerView';
import AdminView from './components/AdminView';
import ErrorBoundary from './components/ErrorBoundary';

const ADMIN_EMAIL = 'roy@mysummitinsuranceagency.com';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'telemarketer' | 'admin'>('telemarketer');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const isAdmin = user.email === ADMIN_EMAIL;

  return (
    <ErrorBoundary>
      {view === 'admin' && isAdmin ? (
        <AdminView onBack={() => setView('telemarketer')} />
      ) : (
        <TelemarketerView
          user={user}
          isAdmin={isAdmin}
          onLogout={() => auth.signOut()}
          onOpenAdmin={() => setView('admin')}
        />
      )}
    </ErrorBoundary>
  );
}
