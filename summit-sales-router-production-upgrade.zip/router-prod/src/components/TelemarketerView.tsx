import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LogOut, Settings as SettingsIcon, User } from 'lucide-react';
import { Agent, ActionType, RouterAdvanceResponse } from '../types';
import { advanceRouterCallable } from '../firebase';

interface Props {
  user: any;
  onLogout: () => void;
  onOpenAdmin: () => void;
  isAdmin: boolean;
}

function getSessionId(userId: string) {
  const existing = localStorage.getItem('router_session_id');
  if (existing) return existing;
  const created = `${userId}_${crypto.randomUUID()}`;
  localStorage.setItem('router_session_id', created);
  return created;
}

export default function TelemarketerView({ user, onLogout, onOpenAdmin, isAdmin }: Props) {
  const [telemarketerName, setTelemarketerName] = useState(localStorage.getItem('telemarketer_name') || '');
  const [draftName, setDraftName] = useState(localStorage.getItem('telemarketer_name') || '');
  const [currentAgent, setCurrentAgent] = useState<Agent | null>(null);
  const [loadingAgent, setLoadingAgent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isNameSet = useMemo(() => telemarketerName.trim().length > 0, [telemarketerName]);
  const sessionId = useMemo(() => getSessionId(user.uid), [user.uid]);

  const loadNextAgent = async (action?: ActionType) => {
    setLoadingAgent(true);
    setError(null);

    try {
      const response = await advanceRouterCallable({
        telemarketerName,
        sessionId,
        action,
        currentAgentId: currentAgent?.id ?? null,
      });

      const data = response.data as RouterAdvanceResponse;
      setCurrentAgent(data.nextAgent ?? null);
    } catch (err) {
      console.error('Routing error:', err);
      setError('Could not load the next recommendation. Please try again.');
    } finally {
      setLoadingAgent(false);
    }
  };

  useEffect(() => {
    if (isNameSet && !currentAgent && !loadingAgent) {
      void loadNextAgent();
    }
  }, [isNameSet]);

  const saveTelemarketerName = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = draftName.trim();
    if (!trimmed) return;

    localStorage.setItem('telemarketer_name', trimmed);
    setTelemarketerName(trimmed);
    setCurrentAgent(null);
    setTimeout(() => {
      void loadNextAgent();
    }, 0);
  };

  const handleAction = async (action: ActionType) => {
    if (!currentAgent || loadingAgent) return;
    await loadNextAgent(action);
  };

  if (!isNameSet) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full border border-gray-100"
        >
          <h1 className="text-2xl font-bold text-gray-900 mb-6 text-center">Next Best Person</h1>
          <p className="text-gray-600 mb-6 text-center">Please enter your name or initials to begin.</p>
          <form onSubmit={saveTelemarketerName}>
            <input
              type="text"
              required
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all mb-4"
              placeholder="Your Name"
              value={draftName}
              onChange={(e) => setDraftName(e.target.value)}
            />
            <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200">
              Start Routing
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <User className="text-blue-600 w-5 h-5" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Telemarketer</p>
            <p className="font-bold text-gray-900">{telemarketerName}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
              title="Admin Dashboard"
            >
              <SettingsIcon className="w-6 h-6" />
            </button>
          )}
          <button
            onClick={onLogout}
            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
            title="Logout"
          >
            <LogOut className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="max-w-2xl w-full text-center">
          <AnimatePresence mode="wait">
            {currentAgent && !loadingAgent ? (
              <motion.div
                key={currentAgent.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="bg-white p-12 rounded-3xl shadow-2xl border border-gray-100 mb-12"
              >
                <h2 className="text-6xl md:text-8xl font-black text-gray-900 mb-2 tracking-tight">
                  {currentAgent.name}
                </h2>
              </motion.div>
            ) : (
              <div className="bg-white p-12 rounded-3xl shadow-2xl border border-gray-100 mb-12 animate-pulse">
                <div className="h-20 bg-gray-200 w-64 mx-auto rounded" />
              </div>
            )}
          </AnimatePresence>

          {error && <p className="text-red-600 font-medium mb-4">{error}</p>}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
            <button
              onClick={() => void handleAction('transferred')}
              disabled={!currentAgent || loadingAgent}
              className="bg-green-600 text-white py-8 rounded-2xl font-bold text-2xl shadow-xl shadow-green-200 hover:bg-green-700 hover:-translate-y-1 transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              Transferred
            </button>
            <button
              onClick={() => void handleAction('skipped')}
              disabled={!currentAgent || loadingAgent}
              className="bg-amber-500 text-white py-8 rounded-2xl font-bold text-2xl shadow-xl shadow-amber-200 hover:bg-amber-600 hover:-translate-y-1 transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              Skipped
            </button>
            <button
              onClick={() => void handleAction('unavailable')}
              disabled={!currentAgent || loadingAgent}
              className="bg-gray-600 text-white py-8 rounded-2xl font-bold text-2xl shadow-xl shadow-gray-200 hover:bg-gray-700 hover:-translate-y-1 transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              Unavailable
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
