import React, { useState, useEffect } from 'react';
import { collection, addDoc, serverTimestamp, query, orderBy, limit, onSnapshot, doc, updateDoc, deleteDoc, getDoc, setDoc, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';
import { Agent, TelemarketerEvent, Stats, AppSettings } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { Trash2, Plus, ArrowLeft, RotateCcw, Save, Activity, Users, Settings as SettingsIcon, CheckCircle2, XCircle } from 'lucide-react';
import { format } from 'date-fns';

interface Props {
  onBack: () => void;
}


const DEFAULT_AGENTS = [
  { name: 'Brady', weight: 30 },
  { name: 'Hayden', weight: 30 },
  { name: 'Nate', weight: 25 },
  { name: 'Cullen', weight: 15 },
];


function getPeriodDocIds(now = new Date()) {
  const day = now.toISOString().slice(0, 10);
  const weekStart = new Date(now);
  const dayOfWeek = weekStart.getUTCDay();
  const diff = (dayOfWeek + 6) % 7;
  weekStart.setUTCDate(weekStart.getUTCDate() - diff);
  const week = weekStart.toISOString().slice(0, 10);
  const month = now.toISOString().slice(0, 7);

  return {
    daily: `daily_${day}`,
    weekly: `weekly_${week}`,
    monthly: `monthly_${month}`,
  };
}

export default function AdminView({ onBack }: Props) {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [events, setEvents] = useState<TelemarketerEvent[]>([]);
  const [stats, setStats] = useState<Record<string, Stats>>({});
  const [settings, setSettings] = useState<AppSettings>({
    skip_penalty_strength: 0.2,
    skip_penalty_duration_ms: 5 * 60 * 1000,
    assignment_hold_duration_ms: 20 * 1000
  });
  const [newAgentName, setNewAgentName] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'agents' | 'logs' | 'settings'>('dashboard');
  const [selectedPeriod, setSelectedPeriod] = useState<'daily' | 'weekly' | 'monthly'>('monthly');

  // Load data
  useEffect(() => {
    const unsubAgents = onSnapshot(collection(db, 'agents'), (snapshot) => {
      setAgents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Agent)));
    });
    const unsubEvents = onSnapshot(query(collection(db, 'events'), orderBy('timestamp', 'desc'), limit(100)), (snapshot) => {
      setEvents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TelemarketerEvent)));
    });
    const periodDocIds = getPeriodDocIds();
    const unsubDaily = onSnapshot(doc(db, 'stats', periodDocIds.daily), (snap) => {
      setStats((prev) => ({
        ...prev,
        daily: snap.exists() ? (snap.data() as Stats) : { period: 'daily', counts: {}, last_reset: null },
      }));
    });
    const unsubWeekly = onSnapshot(doc(db, 'stats', periodDocIds.weekly), (snap) => {
      setStats((prev) => ({
        ...prev,
        weekly: snap.exists() ? (snap.data() as Stats) : { period: 'weekly', counts: {}, last_reset: null },
      }));
    });
    const unsubMonthly = onSnapshot(doc(db, 'stats', periodDocIds.monthly), (snap) => {
      setStats((prev) => ({
        ...prev,
        monthly: snap.exists() ? (snap.data() as Stats) : { period: 'monthly', counts: {}, last_reset: null },
      }));
    });
    const unsubSettings = onSnapshot(doc(db, 'settings', 'engine'), (doc) => {
      if (doc.exists()) setSettings(doc.data() as AppSettings);
    });

    return () => {
      unsubAgents();
      unsubEvents();
      unsubDaily();
      unsubWeekly();
      unsubMonthly();
      unsubSettings();
    };
  }, []);

  const addAgent = async () => {
    if (!newAgentName.trim()) return;
    await addDoc(collection(db, 'agents'), {
      name: newAgentName,
      weight: 1,
      active: true,
      created_at: serverTimestamp(),
      updated_at: serverTimestamp()
    });
    setNewAgentName('');
  };

  const seedDefaultAgents = async () => {
    if (agents.length > 0) return;

    await Promise.all(
      DEFAULT_AGENTS.map((agent) =>
        addDoc(collection(db, 'agents'), {
          ...agent,
          active: true,
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        })
      )
    );
  };

  const updateAgent = async (id: string, data: Partial<Agent>) => {
    await updateDoc(doc(db, 'agents', id), { ...data, updated_at: serverTimestamp() });
  };

  const deleteAgent = async (id: string) => {
    if (confirm('Are you sure you want to delete this agent?')) {
      await deleteDoc(doc(db, 'agents', id));
    }
  };

  const resetStats = async (period: string) => {
    if (confirm(`Reset all ${period} statistics?`)) {
      const periodDocIds = getPeriodDocIds();
      await setDoc(doc(db, 'stats', periodDocIds[period as 'daily' | 'weekly' | 'monthly']), {
        period,
        period_key: periodDocIds[period as 'daily' | 'weekly' | 'monthly'],
        counts: {},
        last_reset: serverTimestamp()
      });
    }
  };

  const undoLastAction = async () => {
    const lastEvent = events[0];
    if (!lastEvent || !lastEvent.undoable) return;

    if (confirm(`Undo last action: ${lastEvent.action_type} for ${lastEvent.agent_name_snapshot}?`)) {
      const batch = writeBatch(db);
      
      // Remove event
      batch.delete(doc(db, 'events', lastEvent.id));

      // Revert stats
      const periods = ['daily', 'weekly', 'monthly'] as const;
      const periodDocIds = getPeriodDocIds();
      for (const period of periods) {
        const statRef = doc(db, 'stats', periodDocIds[period]);
        const statDoc = stats[period];
        if (statDoc) {
          const agentStats = statDoc.counts[lastEvent.agent_id];
          if (agentStats) {
            const newCounts = { ...statDoc.counts };
            const updatedAgentStats = { ...agentStats };
            
            // @ts-ignore
            updatedAgentStats[lastEvent.action_type] = Math.max(0, updatedAgentStats[lastEvent.action_type] - 1);
            if (lastEvent.counted_toward_weight) {
              updatedAgentStats.exposure = Math.max(0, updatedAgentStats.exposure - 1);
            }
            
            newCounts[lastEvent.agent_id] = updatedAgentStats;
            batch.update(statRef, { counts: newCounts });
          }
        }
      }

      await batch.commit();
    }
  };

  const chartData = agents.map(agent => {
    const periodStats = (stats[selectedPeriod]?.counts[agent.id] || { transferred: 0, skipped: 0, unavailable: 0, exposure: 0 }) as { transferred: number; skipped: number; unavailable: number; exposure: number };
    const totalExposure = Object.values(stats[selectedPeriod]?.counts || {}).reduce((sum: number, s: any) => sum + (s.exposure || 0), 0) as number;
    const actualShare = totalExposure > 0 ? (periodStats.exposure / totalExposure) * 100 : 0;
    const totalWeight = agents.reduce((sum, a) => sum + a.weight, 0);
    const targetShare = totalWeight > 0 ? (agent.weight / totalWeight) * 100 : 0;

    return {
      name: agent.name,
      transferred: periodStats.transferred,
      skipped: periodStats.skipped,
      unavailable: periodStats.unavailable,
      actualShare: parseFloat(actualShare.toFixed(1)),
      targetShare: parseFloat(targetShare.toFixed(1))
    };
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-500" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={undoLastAction}
            disabled={!events[0]?.undoable}
            className="flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-700 rounded-lg font-medium hover:bg-amber-100 disabled:opacity-50 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Undo Last
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <nav className="w-64 bg-white border-r border-gray-200 p-4 flex flex-col gap-2">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <Activity className="w-5 h-5" /> Dashboard
          </button>
          <button 
            onClick={() => setActiveTab('agents')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'agents' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <Users className="w-5 h-5" /> Agents
          </button>
          <button 
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'logs' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <Activity className="w-5 h-5" /> Activity Log
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <SettingsIcon className="w-5 h-5" /> Settings
          </button>
        </nav>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8">
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Performance Overview</h2>
                  <p className="text-gray-500">Real-time distribution vs target weights</p>
                </div>
                <div className="flex bg-white border border-gray-200 rounded-lg p-1">
                  {(['daily', 'weekly', 'monthly'] as const).map(p => (
                    <button
                      key={p}
                      onClick={() => setSelectedPeriod(p)}
                      className={`px-4 py-1.5 rounded-md text-sm font-medium capitalize transition-all ${selectedPeriod === p ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <h3 className="text-lg font-bold mb-6">Actual vs Target Share (%)</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} />
                        <YAxis axisLine={false} tickLine={false} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                        />
                        <Bar dataKey="actualShare" name="Actual Share" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="targetShare" name="Target Share" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <h3 className="text-lg font-bold mb-6">Action Distribution</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={100} />
                        <Tooltip />
                        <Bar dataKey="transferred" name="Transferred" stackId="a" fill="#22c55e" />
                        <Bar dataKey="skipped" name="Skipped" stackId="a" fill="#f59e0b" />
                        <Bar dataKey="unavailable" name="Unavailable" stackId="a" fill="#94a3b8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Agent</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Weight</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Transferred</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Skipped</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Actual Share</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {chartData.map(data => (
                      <tr key={data.name} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4 font-bold text-gray-900">{data.name}</td>
                        <td className="px-6 py-4 text-gray-600">{agents.find(a => a.name === data.name)?.weight}</td>
                        <td className="px-6 py-4 text-green-600 font-medium">{data.transferred}</td>
                        <td className="px-6 py-4 text-amber-600 font-medium">{data.skipped}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-blue-500" 
                                style={{ width: `${data.actualShare}%` }}
                              />
                            </div>
                            <span className="text-sm font-bold text-gray-900">{data.actualShare}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end gap-4">
                <button onClick={() => resetStats('daily')} className="px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors">Reset Daily</button>
                <button onClick={() => resetStats('weekly')} className="px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors">Reset Weekly</button>
                <button onClick={() => resetStats('monthly')} className="px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors">Reset Monthly</button>
              </div>
            </div>
          )}

          {activeTab === 'agents' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Manage Agents</h2>
                <div className="flex gap-2">
                  {agents.length === 0 && (
                    <button onClick={seedDefaultAgents} className="bg-gray-900 text-white px-4 py-2 rounded-xl font-bold hover:bg-black transition-colors">
                      Seed Defaults
                    </button>
                  )}
                  <input 
                    type="text" 
                    placeholder="New agent name..." 
                    className="px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    value={newAgentName}
                    onChange={(e) => setNewAgentName(e.target.value)}
                  />
                  <button onClick={addAgent} className="bg-blue-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-blue-700 transition-colors flex items-center gap-2">
                    <Plus className="w-5 h-5" /> Add Agent
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {agents.map(agent => (
                  <div key={agent.id} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">{agent.name}</h3>
                        <p className="text-xs text-gray-400">Added {agent.created_at ? format(agent.created_at.toDate(), 'MMM d, yyyy') : 'Recently'}</p>
                      </div>
                      <button 
                        onClick={() => updateAgent(agent.id, { active: !agent.active })}
                        className={`p-2 rounded-lg transition-colors ${agent.active ? 'text-green-600 bg-green-50' : 'text-gray-400 bg-gray-50'}`}
                      >
                        {agent.active ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Weight</label>
                        <div className="flex items-center gap-3">
                          <input 
                            type="range" 
                            min="1" 
                            max="100" 
                            step="1"
                            className="flex-1 accent-blue-600"
                            value={agent.weight}
                            onChange={(e) => updateAgent(agent.id, { weight: parseInt(e.target.value) })}
                          />
                          <span className="font-bold text-blue-600 w-8 text-center">{agent.weight}</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center pt-4 border-t border-gray-50">
                        <button 
                          onClick={() => deleteAgent(agent.id)}
                          className="text-red-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                        <span className={`text-xs font-bold px-2 py-1 rounded-full ${agent.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                          {agent.active ? 'ACTIVE' : 'INACTIVE'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Activity Log</h2>
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Time</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Telemarketer</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Action</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-500 uppercase tracking-wider">Agent</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {events.map(event => (
                      <tr key={event.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4 text-sm text-gray-500">
                          {event.timestamp ? format(event.timestamp.toDate(), 'MMM d, h:mm a') : 'Just now'}
                        </td>
                        <td className="px-6 py-4 font-medium text-gray-900">{event.telemarketer_name}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
                            event.action_type === 'transferred' ? 'bg-green-100 text-green-700' :
                            event.action_type === 'skipped' ? 'bg-amber-100 text-amber-700' :
                            'bg-gray-100 text-gray-700'
                          }`}>
                            {event.action_type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{event.agent_name_snapshot}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="max-w-xl space-y-8">
              <h2 className="text-2xl font-bold text-gray-900">Engine Settings</h2>
              
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm space-y-8">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Skip Penalty Strength</label>
                  <p className="text-xs text-gray-500 mb-4">How much to reduce an agent's weight after a skip. (0.1 = 90% reduction, 1.0 = no penalty)</p>
                  <div className="flex items-center gap-4">
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.05"
                      className="flex-1 accent-blue-600"
                      value={settings.skip_penalty_strength}
                      onChange={(e) => setSettings({ ...settings, skip_penalty_strength: parseFloat(e.target.value) })}
                    />
                    <span className="font-mono font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-lg">
                      {settings.skip_penalty_strength.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Skip Penalty Duration (Minutes)</label>
                  <p className="text-xs text-gray-500 mb-4">How long the penalty lasts before the weight returns to normal.</p>
                  <div className="flex items-center gap-4">
                    <input 
                      type="number" 
                      className="w-24 px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                      value={settings.skip_penalty_duration_ms / 60000}
                      onChange={(e) => setSettings({ ...settings, skip_penalty_duration_ms: parseInt(e.target.value || '0', 10) * 60000 })}
                    />
                    <span className="text-gray-500 font-medium">minutes</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Assignment Hold Duration (Seconds)</label>
                  <p className="text-xs text-gray-500 mb-4">How long an agent is temporarily reserved after being assigned so two telemarketers do not get the same name at once.</p>
                  <div className="flex items-center gap-4">
                    <input 
                      type="number" 
                      className="w-24 px-3 py-2 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                      value={settings.assignment_hold_duration_ms / 1000}
                      onChange={(e) => setSettings({ ...settings, assignment_hold_duration_ms: parseInt(e.target.value || '0', 10) * 1000 })}
                    />
                    <span className="text-gray-500 font-medium">seconds</span>
                  </div>
                </div>

                <button 
                  onClick={async () => {
                    await setDoc(doc(db, 'settings', 'engine'), settings);
                    alert('Settings saved!');
                  }}
                  className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" /> Save Configuration
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
