export interface Agent {
  id: string;
  name: string;
  weight: number;
  active: boolean;
  created_at?: any;
  updated_at?: any;
  busyUntil?: any | null;
  skipPenaltyUntil?: any | null;
}

export type ActionType = 'transferred' | 'skipped' | 'unavailable';

export interface TelemarketerEvent {
  id: string;
  timestamp: any;
  telemarketer_name: string;
  action_type: ActionType;
  agent_id: string;
  agent_name_snapshot: string;
  counted_toward_weight: boolean;
  undoable: boolean;
}

export interface Stats {
  period: 'daily' | 'weekly' | 'monthly';
  counts: Record<string, {
    transferred: number;
    skipped: number;
    unavailable: number;
    exposure: number;
  }>;
  last_reset: any;
}

export interface AppSettings {
  skip_penalty_strength: number;
  skip_penalty_duration_ms: number;
  assignment_hold_duration_ms: number;
}

export interface RouterAdvanceRequest {
  telemarketerName: string;
  sessionId: string;
  action?: ActionType;
  currentAgentId?: string | null;
}

export interface RouterAdvanceResponse {
  nextAgent: Agent | null;
}
