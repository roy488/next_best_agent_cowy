import * as admin from 'firebase-admin';
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { logger } from 'firebase-functions';

admin.initializeApp();
const db = admin.firestore();
const { FieldValue, Timestamp } = admin.firestore;

type ActionType = 'transferred' | 'skipped' | 'unavailable';

type Agent = {
  id: string;
  name: string;
  weight: number;
  active: boolean;
  busyUntil?: FirebaseFirestore.Timestamp | null;
  skipPenaltyUntil?: FirebaseFirestore.Timestamp | null;
};

type Settings = {
  skip_penalty_strength: number;
  skip_penalty_duration_ms: number;
  assignment_hold_duration_ms: number;
};

const DEFAULT_SETTINGS: Settings = {
  skip_penalty_strength: 0.2,
  skip_penalty_duration_ms: 5 * 60 * 1000,
  assignment_hold_duration_ms: 20 * 1000,
};

function getPeriodKeys(now: Date) {
  const day = now.toISOString().slice(0, 10);
  const weekStart = new Date(now);
  const dayOfWeek = weekStart.getUTCDay();
  const diff = (dayOfWeek + 6) % 7;
  weekStart.setUTCDate(weekStart.getUTCDate() - diff);
  const week = weekStart.toISOString().slice(0, 10);
  const month = now.toISOString().slice(0, 7);

  return {
    daily: `daily_${day}`,
    weekly: `weekly_${week}`,
    monthly: `monthly_${month}`,
  };
}

function weightedPick(agents: Agent[], settings: Settings, nowMs: number): Agent {
  const weightedPool = agents.map((agent) => {
    const penalized = agent.skipPenaltyUntil && agent.skipPenaltyUntil.toMillis() > nowMs;
    const weight = penalized ? agent.weight * settings.skip_penalty_strength : agent.weight;
    return { agent, weight: Math.max(weight, 0.0001) };
  });

  const totalWeight = weightedPool.reduce((sum, item) => sum + item.weight, 0);
  let cursor = Math.random() * totalWeight;

  for (const item of weightedPool) {
    if (cursor < item.weight) {
      return item.agent;
    }
    cursor -= item.weight;
  }

  return weightedPool[weightedPool.length - 1].agent;
}

export const advanceRouter = onCall({ region: 'us-central1', cors: true }, async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'You must be signed in.');
  }

  const telemarketerName = String(request.data?.telemarketerName || '').trim();
  const sessionId = String(request.data?.sessionId || '').trim();
  const action = request.data?.action as ActionType | undefined;
  const currentAgentId = request.data?.currentAgentId ? String(request.data.currentAgentId) : null;

  if (!telemarketerName) {
    throw new HttpsError('invalid-argument', 'telemarketerName is required.');
  }

  if (!sessionId) {
    throw new HttpsError('invalid-argument', 'sessionId is required.');
  }

  const settingsRef = db.doc('settings/engine');
  const sessionRef = db.doc(`sessions/${sessionId}`);
  const agentsQuery = db.collection('agents').where('active', '==', true);
  const now = new Date();
  const nowTs = Timestamp.fromDate(now);
  const nowMs = now.getTime();
  const periodKeys = getPeriodKeys(now);

  const nextAgent = await db.runTransaction(async (tx) => {
    const [settingsSnap, sessionSnap, agentsSnap] = await Promise.all([
      tx.get(settingsRef),
      tx.get(sessionRef),
      tx.get(agentsQuery),
    ]);

    const settings = { ...DEFAULT_SETTINGS, ...(settingsSnap.data() || {}) } as Settings;
    const sessionData = sessionSnap.exists ? sessionSnap.data() : {};

    if (action && currentAgentId) {
      const currentAgentRef = db.doc(`agents/${currentAgentId}`);
      const currentAgentSnap = await tx.get(currentAgentRef);

      if (currentAgentSnap.exists) {
        const currentAgent = currentAgentSnap.data() as Omit<Agent, 'id'>;
        const eventRef = db.collection('events').doc();
        tx.set(eventRef, {
          timestamp: nowTs,
          telemarketer_name: telemarketerName,
          action_type: action,
          agent_id: currentAgentId,
          agent_name_snapshot: currentAgent.name,
          counted_toward_weight: action !== 'unavailable',
          undoable: true,
          session_id: sessionId,
        });

        if (action === 'skipped') {
          tx.update(currentAgentRef, {
            busyUntil: nowTs,
            skipPenaltyUntil: Timestamp.fromMillis(nowMs + settings.skip_penalty_duration_ms),
            updated_at: nowTs,
          });
        } else {
          tx.update(currentAgentRef, {
            busyUntil: nowTs,
            updated_at: nowTs,
          });
        }

        for (const [period, docId] of Object.entries(periodKeys)) {
          const statRef = db.doc(`stats/${docId}`);
          tx.set(
            statRef,
            {
              period,
              period_key: docId,
              last_reset: FieldValue.serverTimestamp(),
              counts: {
                [currentAgentId]: {
                  [action]: FieldValue.increment(1),
                  ...(action !== 'unavailable' ? { exposure: FieldValue.increment(1) } : {}),
                },
              },
            },
            { merge: true }
          );
        }
      }
    }

    const agents = agentsSnap.docs.map((snap) => ({ id: snap.id, ...(snap.data() as Omit<Agent, 'id'>) }));
    if (!agents.length) {
      tx.set(sessionRef, {
        telemarketerName,
        currentAgentId: null,
        updatedAt: nowTs,
      }, { merge: true });
      return null;
    }

    let candidates = agents.filter((agent) => !agent.busyUntil || agent.busyUntil.toMillis() <= nowMs);
    if (!candidates.length) {
      candidates = agents;
    }

    const lastServedAgentId = typeof sessionData?.lastServedAgentId === 'string' ? sessionData.lastServedAgentId : null;
    const withoutLast = candidates.filter((agent) => agent.id !== lastServedAgentId);
    if (withoutLast.length > 0) {
      candidates = withoutLast;
    }

    const chosen = weightedPick(candidates, settings, nowMs);
    const chosenRef = db.doc(`agents/${chosen.id}`);

    tx.update(chosenRef, {
      busyUntil: Timestamp.fromMillis(nowMs + settings.assignment_hold_duration_ms),
      updated_at: nowTs,
    });

    tx.set(
      sessionRef,
      {
        telemarketerName,
        currentAgentId: chosen.id,
        lastServedAgentId: chosen.id,
        updatedAt: nowTs,
      },
      { merge: true }
    );

    return chosen;
  });

  logger.info('advanceRouter success', {
    telemarketerName,
    sessionId,
    action: action || null,
    nextAgentId: nextAgent?.id || null,
  });

  return { nextAgent };
});
